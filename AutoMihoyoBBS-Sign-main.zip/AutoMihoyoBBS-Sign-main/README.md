## 🌀米游社自动签到

基于Python3的米游社自动签到项目

本项目米游币部分参考[XiaoMiku01/miyoubiAuto](https://github.com/XiaoMiku01/miyoubiAuto)进行编写

* 此项目的用途

  这是一个米游社的自动签到项目，包含了米游币获取和原神以及崩坏3签到

## 📐部署
<details>
<summary>查看方法一</summary>

  1. Fork 仓库
  
  2. 获取 Cookie
  
  3. 添加 Cookie 至 Secrets
  
  4. 启用 Action

  <div><details>
  <summary>查看方法一详细教程</summary>

### 1. Fork 仓库

- 项目地址：[github/AutoMihoyoBBS-Sign](https://github.com/KuDikan/AutoMihoyoBBS-Sign)
- 点击右上角`Fork`到自己的账号下

![fork](https://i.loli.net/2020/10/28/qpXowZmIWeEUyrJ.png)

- 将仓库默认分支设置为 master 分支

### 2. 获取 Cookie

浏览器打开 https://bbs.mihoyo.com/ys/ 并登录账号 **(如果已经登录请退出重登)**

#### 2.1 法一

- 按`F12`，打开`开发者工具`，找到`Network`并点击
- 按`F5`刷新页面，按下图复制`Cookie`

![cookie](https://i.loli.net/2020/10/28/TMKC6lsnk4w5A8i.png)

- 当触发`Debugger`时，可尝试按`Ctrl + F8`关闭，然后再次刷新页面，最后复制`Cookie`

#### 2.2 法二

- 复制以下代码

```
var cookie = document.cookie;
var ask = confirm('Cookie:' + cookie + '\n\n是否复制内容到剪切板？');
if (ask == true) {
    copy(cookie);
    msg = cookie;
} else {
    msg = 'Cancel';
}
```

- 按`F12`，打开`开发者工具`，找到`Console`并点击
- 命令行粘贴代码并运行，获得类似`Cookie:xxxxxx`的输出信息
- `xxxxxx`部分即为所需复制的`Cookie`，点击确定复制

### 3. 添加 Cookie 

- 打开目录中的**config文件夹**复制`config.json.example`并改名为`config.json`，如果需要使用多用户的功能的话请改名成`xxx.json`
    
### 4. 启用 Actions

> Actions 默认为关闭状态，Fork 之后需要手动执行一次，若成功运行其才会激活。

返回项目主页面，点击上方的`Actions`，再点击左侧的`Mihoyo BBS Sign`，再点击`Run workflow`

![run](https://i.loli.net/2020/10/28/5ylvgdYf9BDMqAH.png)

  </details></div>
</details>
<details>
<summary>查看方法二</summary>
  
  1.下载项目
  
  2.设置 COOKIE(config.json:"mihoyobbs_Cookies")
  
  3.运行 main.py
  
  <details>
  <summary>查看方法二详细教程</summary>
  
  1. 下载[本项目]

  2. 下载[Python3](https://www.python.org/downloads/)

  3. 解压本项目压缩包,在解压目录中**Shift+右键** 打开你的命令提示符cmd或powershell

  4. [requirements.txt](https://github.com/KuDikan/AutoMihoyoBBS-Sign/blob/main/requirements.txt) 是所需第三方模块，执行 `pip install -r requirements.txt` 安装模块

  5. 打开目录中的**config文件夹**复制`config.json.example`并改名为`config.json`，如果需要使用多用户的功能的话请改名成`xxx.json`

  6. 请使用vscode/notepad++等文本编辑器打开上一步复制好的配置文件

  7. **使用[获取Cookie](#2-获取-cookie)里面的方法来获取米游社Cookie**

  8. 将复制的Cookie粘贴到`config.json`的`"mihoyobbs_Cookies":" "`中

        例子

        > ```json
        > "mihoyobbs_Cookies": "你复制的cookie"
        > ```

  9. 在命令提示符(cmd)/powershell，输入`python main.py`来进行执行
  
  10. 多用户的请使用`python main_multi.py`，多用户在需要自动执行的情况下请使用`python main_multi.py autorun`

  </details>
</details>
至此，部署完毕。

## ❗️License

[License](https://github.com/KuDikan/AutoMihoyoBBS-Sign/blob/main/LICENSE)
